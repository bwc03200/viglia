import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { AlertTriangle, Signal } from "lucide-react";
import { useVigla } from "@/lib/vigla-store";
import { haversine, formatDistance, formatSpeed, speedUnitLabel } from "@/lib/geo";
import { hazardLabel } from "@/lib/i18n-helpers";
import { useSpeedLimit } from "@/hooks/useRouteMilestones";

export function TopBar({ embedded = false }: { embedded?: boolean } = {}) {
  const { t } = useTranslation();
  const position = useVigla((s) => s.position);
  const speedKmh = useVigla((s) => s.speedKmh);
  const hazards = useVigla((s) => s.hazards);
  const speedUnit = useVigla((s) => s.preferences.speed_unit);
  const route = useVigla((s) => s.route);
  const navActive = useVigla((s) => Boolean(s.navigation && !s.navigation.arrived));
  const speedLimit = useSpeedLimit();
  const overLimit = speedLimit != null && speedKmh > speedLimit;

  const nextHazard = useMemo(() => {
    if (!position) return null;
    const allowed = route ? new Set(route.hazardIds) : null;
    let best: { label: string; distance: number } | null = null;
    for (const h of hazards) {
      if (allowed && !allowed.has(h.id)) continue;
      const d = haversine(position.lat, position.lng, h.latitude, h.longitude);
      if (d < 3000 && (!best || d < best.distance)) {
        best = { label: hazardLabel(h.type), distance: d };
      }
    }
    return best;
  }, [hazards, position, route]);

  if (navActive && !embedded) return null;

  const wrapperClass = embedded
    ? ""
    : "pointer-events-none absolute inset-x-0 top-0 z-[500] p-3";

  return (
    <div className={wrapperClass}>
      <div className="pointer-events-auto flex items-center gap-3 rounded-2xl bg-white px-4 py-2.5 shadow-[0_8px_24px_rgba(15,23,42,0.12)] ring-1 ring-slate-200">
        <div className="flex flex-col items-center leading-none">
          <span
            className={`vigla-speed-value tabular-nums font-bold ${overLimit ? "vigla-speed-over text-[#e2313f]" : "text-slate-900"} ${embedded ? "text-[20px]" : "text-[32px]"}`}
            style={{
              fontFeatureSettings: '"tnum"',
              textShadow: overLimit ? "0 0 10px rgba(226,49,63,0.35)" : undefined,
            }}
          >
            {formatSpeed(speedKmh, speedUnit)}
          </span>
          <span className={`uppercase tracking-widest text-slate-500 ${embedded ? "text-[9px]" : "text-[10px]"}`}>
            {speedUnitLabel(speedUnit)}
          </span>
        </div>
        {speedLimit != null && (
          <div
            className={`flex shrink-0 items-center justify-center rounded-full border-[3px] border-[#e2313f] bg-white font-bold tabular-nums text-slate-900 ${embedded ? "h-7 w-7 text-[11px]" : "h-9 w-9 text-[13px]"}`}
          >
            {speedLimit}
          </div>
        )}
        <div className={`w-px bg-slate-200 ${embedded ? "h-7" : "h-10"}`} />

        <div className="min-w-0 flex-1">
          {nextHazard ? (
            <div key={nextHazard.label} className="vigla-topbar-alert flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 shrink-0 text-[#FF6B35]" />
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold text-slate-900">
                  {nextHazard.label}
                </div>
                <div className="text-xs text-slate-500">
                  {t("map.in", { distance: formatDistance(nextHazard.distance) })}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-slate-500">
              <Signal className="h-4 w-4" />
              <span className="text-xs">
                {route ? t("map.routeActive") : t("map.clear")}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
